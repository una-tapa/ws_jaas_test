/* A WebSphere Application Server User Registry tester */
/* Use to test correct operation of UserRegistry implementation */
/* 
   Usage: java -classpath wssec.jar;sas.jar DB2UserRegistrySampleTest <classname> <property_file>,
   where classname is class of registry implementation (i.e. DB2UserRegistrySampleTest), 
   property_file is file containing initialisation properties for 
   implementation's initialize method (i.e. db2userregistry.properties)
*/

import java.io.*;
import java.util.Properties;
import java.security.cert.*;

import com.ibm.websphere.security.UserRegistry;

public class DB2UserRegistrySampleTest {
    public UserRegistry ur;

    public static void main(String[] args) throws Exception {
	if (args[0].equals("") || args[1].equals("")) System.exit(1);
	Properties props=new Properties();
	props.load(new FileInputStream(args[1]));

	DB2UserRegistrySampleTest urt=new DB2UserRegistrySampleTest(args[0],props);
	System.out.println("Initialised "+urt.ur.getClass().getName());

	BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
	System.out.print("Enter a user name. ");
	String username=in.readLine();
	System.out.print("Enter a UID. ");
	String userID=in.readLine();
	System.out.print("Enter a group name. ");
	String groupname=in.readLine();
	System.out.print("Enter a GID. ");
	String groupID=in.readLine();
	System.out.print("Enter a password. ");
	String password=in.readLine();
	System.out.print("X509 certificate file. ");
	String certfile=in.readLine();
	X509Certificate[] cert=null;
	if (!certfile.equals("")) {
	    InputStream inStream=new FileInputStream(certfile);
	    CertificateFactory cf=CertificateFactory.getInstance("X.509");
	    cert=new X509Certificate[1];
	    cert[0]=(X509Certificate)cf.generateCertificate(inStream);
	    inStream.close();
	}

	urt.test(username,userID,groupname,groupID,password,cert);
    }

    public DB2UserRegistrySampleTest(String in,Properties props) throws Exception {
        this.ur=(UserRegistry)(Class.forName(in)).newInstance();
	this.ur.initialize(props);  // initialise the implementation
    }

    public UserRegistry getRegistry() {
	return this.ur;
    }

    public boolean test(String username,String userID,String groupname,String groupID,String password,X509Certificate[] cert) {
	// test the implementation...
	System.out.println("Testing registry...");
	try {
	    System.out.println("checkPassword: "+this.ur.checkPassword(username,password));
	    System.out.println("getGroupDisplayName: "+this.ur.getGroupDisplayName(groupname));
	    System.out.println("getGroups: "+this.ur.getGroups("",1));
	    System.out.println("getGroupSecurityName: "+this.ur.getGroupSecurityName(groupID));
	    String realm=this.ur.getRealm();
	    System.out.print("getRealm: ");
	    if (realm==null) System.out.println("customRealm"); else System.out.println(realm);
	    System.out.println("getUniqueGroupId: "+this.ur.getUniqueGroupId(groupname));
	    System.out.println("getUniqueGroupIds: "+this.ur.getUniqueGroupIds(userID));
	    System.out.println("getGroupsForUser: "+this.ur.getGroupsForUser(username));
	    System.out.println("getUniqueUserId: "+this.ur.getUniqueUserId(username));
	    System.out.println("getUserDisplayName: "+this.ur.getUserDisplayName(username));
	    System.out.println("getUsers: "+this.ur.getUsers("",1));
	    System.out.println("getUserSecurityName: "+this.ur.getUserSecurityName(userID));
	    System.out.println("isValidGroup: "+this.ur.isValidGroup(groupname));
	    System.out.println("isValidUser: "+this.ur.isValidUser(username));
	    System.out.println("mapCertificate: "+this.ur.mapCertificate(cert));

	    System.out.println("Test completed.");
	} catch (Exception e) {
	    System.out.println(e);
	    System.out.println("Test failed");
	}


	return true;
    }
}
