import java.rmi.RemoteException;
import java.security.cert.X509Certificate;
import java.util.*;
import java.sql.*;

import com.ibm.websphere.security.*;

public class DB2UserRegistrySample implements UserRegistry {
    private static String DBDRIVER=null;
    private static String DBURL=null;
    private static String DBUSERNAME=null;
    private static String DBPASSWORD=null;
    private static String DBSCHEMA=null;

    private static Connection con=null;
    private static Statement stmt=null;
	
    public void initialize(Properties props) throws CustomRegistryException,RemoteException {
	try {
	    if (props!=null) {
		DBDRIVER=props.getProperty("DBDRIVER");  // extract database driver
		DBURL=props.getProperty("DBURL");  // extract database URL property
		DBUSERNAME=props.getProperty("DBUSERNAME");  // extract database login username
		DBPASSWORD=props.getProperty("DBPASSWORD");  // extract database login password
		DBSCHEMA=props.getProperty("DBSCHEMA");
	    }
	} catch (Exception e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	if (DBDRIVER==null || DBURL==null || DBUSERNAME==null || DBPASSWORD==null || DBSCHEMA==null) {
	    throw new CustomRegistryException("Database property information missing");
	}

	try {
		System.out.println(DBDRIVER);
		// connect to database...
	    DriverManager.registerDriver((Driver)(Class.forName(DBDRIVER).newInstance()));
	    System.out.println(DBURL + ":" + DBUSERNAME + ":" + DBPASSWORD);
	    con = DriverManager.getConnection(DBURL,DBUSERNAME,DBPASSWORD);
	    System.out.println(con);
	    stmt = con.createStatement();
	} catch (Exception e) {
				e.printStackTrace();
			    throw new CustomRegistryException(e.getMessage());
	}
    }

    public String checkPassword(String userSecurityName,String password) throws PasswordCheckFailedException,CustomRegistryException,RemoteException {
	// checks the password of the user...
	String rsPassword="";
	try {
	    ResultSet rs=stmt.executeQuery("SELECT PASSWORD FROM "+DBSCHEMA+".USERS WHERE USERNAME='"+userSecurityName+"'");
	    if (rs.next()) rsPassword=rs.getString("PASSWORD");
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	if (password.equals(rsPassword.trim())) return userSecurityName;
	else throw new PasswordCheckFailedException();
    }

    public String mapCertificate(java.security.cert.X509Certificate[] cert) throws CertificateMapNotSupportedException,CertificateMapFailedException,CustomRegistryException,RemoteException {
	if (cert==null) return null;  // special case
	String name=null;
	X509Certificate cert1=null;
	if (cert.length>0) cert1=cert[0];
	else throw new CertificateMapFailedException("Certificate not found");

	try {
	    // map the SubjectDN in the certificate to a userID.
	    name=cert1.getSubjectDN().getName();
	} catch(Exception e) {
	    throw new CertificateMapNotSupportedException(e.getMessage());
	}

	try {
	    this.getUniqueUserId(name);
	} catch (EntryNotFoundException e) {
	    throw new CertificateMapFailedException(e.getMessage());
	}
	return name;
    }

    public String getRealm() throws CustomRegistryException,RemoteException {
	return null;
    }

    public Result getUsers(String pattern,int limit) throws CustomRegistryException,RemoteException {
	List allUsers=new ArrayList();
	Result result=new Result();
	ResultSet rs=null;
	//	 To allow for the '*' wildcard from WebSphere, we change it to the SQL wildcard '%'
	pattern = pattern.replace('*','%');
	int i=0;
	try {
	    stmt.setFetchSize(limit);
	    rs=stmt.executeQuery("SELECT USERNAME FROM "+DBSCHEMA+".USERS WHERE USERNAME LIKE '%"+pattern+"%'");
	    while (rs.next() && ++i<=limit) allUsers.add(rs.getString("USERNAME").trim());
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}

	if (i==limit) result.setHasMore();
	result.setList(allUsers);
	return result;
    }

    public String getUserDisplayName(String userSecurityName) throws EntryNotFoundException,CustomRegistryException,RemoteException {
	ResultSet rs=null;
	String result="";
	try {
	    rs=stmt.executeQuery("SELECT DESC FROM "+DBSCHEMA+".USERS WHERE USERNAME='"+userSecurityName+"'");
	    if (rs.next()) result=rs.getString("DESC");
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	if (result.equals("")) throw new EntryNotFoundException(userSecurityName);
	else return result.trim();
    }

    public String getUniqueUserId(String userSecurityName) throws EntryNotFoundException,CustomRegistryException,RemoteException {
	ResultSet rs=null;
	String result="";
	try {
	    rs=stmt.executeQuery("SELECT UID FROM "+DBSCHEMA+".USERS WHERE USERNAME='"+userSecurityName+"'");
	    if (rs.next()) result=rs.getString("UID");
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	if (result.equals("")) throw new EntryNotFoundException(userSecurityName);
	else return result.trim();
    }

    public String getUserSecurityName(String uniqueUserId) throws EntryNotFoundException,CustomRegistryException,RemoteException {
	ResultSet rs=null;
	String result="";
	try {
	    rs=stmt.executeQuery("SELECT USERNAME FROM "+DBSCHEMA+".USERS WHERE UID="+uniqueUserId);
	    if (rs.next()) result=rs.getString("USERNAME");
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	if (result.equals("")) throw new EntryNotFoundException(uniqueUserId);
	else return result.trim();
    }

    public boolean isValidUser(String userSecurityName) throws CustomRegistryException,RemoteException {
	ResultSet rs=null;
	boolean result=false;
	try {
	    rs=stmt.executeQuery("SELECT UID FROM "+DBSCHEMA+".USERS WHERE USERNAME='"+userSecurityName+"'");
	    if (rs.next()) result=(rs.getString("UID").equals("") ? false : true);
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	return result;
    }

    public Result getGroups(String pattern,int limit) throws CustomRegistryException,RemoteException {
	List allGroups=new ArrayList();
	Result result=new Result();
	ResultSet rs=null;
	// To allow for the '*' wildcard from WebSphere, we change it to the SQL wildcard '%'
	pattern = pattern.replace('*','%');
	try {
	    stmt.setFetchSize(limit);
	    rs=stmt.executeQuery("SELECT NAME FROM "+DBSCHEMA+".GROUPS WHERE NAME LIKE '%"+pattern+"%'");
	    int i=0;
	    while (rs.next() && ++i<=limit) allGroups.add(rs.getString("NAME").trim());

	    if (i==limit) result.setHasMore();
	    result.setList(allGroups);
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	return result;
    }

    public String getGroupDisplayName(String groupSecurityName) throws EntryNotFoundException,CustomRegistryException,RemoteException {
	ResultSet rs=null;
	String result="";
	try {
	    rs=stmt.executeQuery("SELECT DESC FROM "+DBSCHEMA+".GROUPS WHERE NAME='"+groupSecurityName+"'");
	    if (rs.next()) result=rs.getString("DESC");
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}

	if (result.equals("")) throw new EntryNotFoundException(groupSecurityName);
	else return result.trim();
    }

    public String getUniqueGroupId(String groupSecurityName) throws EntryNotFoundException,CustomRegistryException,RemoteException {
	ResultSet rs=null;
	String result="";
	try {
	    rs=stmt.executeQuery("SELECT GID FROM "+DBSCHEMA+".GROUPS WHERE NAME='"+groupSecurityName+"'");
	    if (rs.next()) result=rs.getString("GID");
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	if (result.equals("")) throw new EntryNotFoundException(groupSecurityName);
	return result.trim();
    }

    public List getUniqueGroupIds(String uniqueUserId) throws EntryNotFoundException,CustomRegistryException,RemoteException {
	ArrayList allGroups=new ArrayList();
	ResultSet rs=null;
	try {
	    rs=stmt.executeQuery("SELECT GID FROM "+DBSCHEMA+".UIDGID WHERE UID="+uniqueUserId);
	    while (rs.next()) allGroups.add(rs.getString("GID").trim());
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	if (allGroups.size()==0) throw new EntryNotFoundException(uniqueUserId);
	return allGroups;
    }

    public String getGroupSecurityName(String uniqueGroupId) throws EntryNotFoundException,CustomRegistryException,RemoteException {
	ResultSet rs=null;
	String result="";
	try {
	    rs=stmt.executeQuery("SELECT NAME FROM "+DBSCHEMA+".GROUPS WHERE GID="+uniqueGroupId);
	    if (rs.next()) result=rs.getString("NAME");
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	if (result.equals("")) throw new EntryNotFoundException(uniqueGroupId);
	else return result.trim();
    }

    public boolean isValidGroup(String groupSecurityName) throws CustomRegistryException,RemoteException {
	ResultSet rs=null;
	boolean result;
	try {
	    rs=stmt.executeQuery("SELECT GID FROM "+DBSCHEMA+".GROUPS WHERE NAME='"+groupSecurityName+"'");
	    rs.next();
	    result=(rs.getString("GID").equals("") ? false : true);
	    // rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}
	return result;
    }

	/** @deprecated */
    public Result getUsersForGroup(String groupSecurityName,int limit) throws NotImplementedException,EntryNotFoundException,CustomRegistryException,RemoteException {
		throw new NotImplementedException();
    }

    public List getGroupsForUser(String userSecurityName) throws EntryNotFoundException,CustomRegistryException,RemoteException {
	ArrayList result=new ArrayList();
	ResultSet rs=null;
	try {
	    rs=stmt.executeQuery("SELECT "+DBSCHEMA+".GROUPS.NAME FROM "+DBSCHEMA+".GROUPS JOIN "+DBSCHEMA+".UIDGID ON "+DBSCHEMA+".GROUPS.GID="+DBSCHEMA+".UIDGID.GID LEFT JOIN "+DBSCHEMA+".USERS ON "+DBSCHEMA+".USERS.UID="+DBSCHEMA+".UIDGID.UID WHERE USERNAME='"+userSecurityName+"'");
	    while (rs.next()) result.add(rs.getString("NAME").trim());
	    rs.close();
	} catch (SQLException e) {
	    throw new CustomRegistryException(e.getMessage());
	}

	if (result.size()==0) throw new EntryNotFoundException(userSecurityName);
	return result;
    }

    public com.ibm.websphere.security.cred.WSCredential createCredential(String userSecurityName) throws NotImplementedException,EntryNotFoundException,CustomRegistryException,RemoteException {
	throw new NotImplementedException();
    }
}
